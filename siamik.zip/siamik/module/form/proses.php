<?php
	
	echo "Nama : ".$_POST['nama'];
	echo "<br>";
	echo "Nim : ".$_POST['nim'];
	echo "<br>";
	echo "Jenis Kelamin : ".$_POST['jenkel'];
	echo "<br>";
	echo "Agama : ".$_POST['agama'];

?>