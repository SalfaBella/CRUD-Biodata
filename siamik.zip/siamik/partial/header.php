<html>

	<title> Sistem Informasi Akademik</title>
	<head>
		
	</head>

	<menu>
		Home	|	Profile		| 	News
	</menu>
	<hr>
	<br><br>